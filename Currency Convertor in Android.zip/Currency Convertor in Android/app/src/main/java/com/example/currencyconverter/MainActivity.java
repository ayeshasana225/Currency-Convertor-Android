package com.example.currencyconverter;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editAmount;
    private Spinner spinnerCurrency;
    private Button buttonConvert;
    private TextView Result;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editAmount = findViewById(R.id.editAmount);
        spinnerCurrency = findViewById(R.id.spinnerCurrency);
        buttonConvert = findViewById(R.id.buttonConvert);
        Result = findViewById(R.id.Result);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.currency_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCurrency.setAdapter(adapter);

        spinnerCurrency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Handle item selection if needed
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here
            }
        });
    }

    public void convertCurrency(View view) {
        // Get the entered amount
        double amount = Double.parseDouble(editAmount.getText().toString());

        // Get the selected currency
        String selectedCurrency = spinnerCurrency.getSelectedItem().toString();

        // Perform conversion based on selected currency
        double result;
        switch (selectedCurrency) {
            case "USD":
                result = amount * 280; // Convert to dollars (assuming 1 rupee = 250 dollars)
                break;
            case "EUR":
                result = amount * 307; // Convert to euros (assuming 1 rupee = 300 euros)
                break;
            case "JPY":
                result = amount * 200; // Convert to yen (assuming 1 rupee = 500 yen)
                break;
            default:
                result = 0;
        }

        // Display the result
        Result.setText(String.format("%.2f %s", result, selectedCurrency));
    }
}
